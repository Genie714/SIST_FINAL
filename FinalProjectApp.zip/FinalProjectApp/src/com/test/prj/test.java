package com.test.prj;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class test
{
	public static void main(String[] args)
	{
		String doublePlan = "&doublePlan=" + 0;
		
		System.out.println(doublePlan.substring(12));
	}
}

/*====================
	MemberDTO.java
====================*/

package com.test.prj;

public class MemberDTO
{
	private String user_id;
	private String my_id, pw, user_name;
	private String birth_date;
	private String gender_id, gender;
	private String find_id, question;
	private String answer;
	private String signup_date;
	
	public String getUser_id()
	{
		return user_id;
	}
	public void setUser_id(String user_id)
	{
		this.user_id = user_id;
	}
	public String getMy_id()
	{
		return my_id;
	}
	public void setMy_id(String my_id)
	{
		this.my_id = my_id;
	}
	public String getPw()
	{
		return pw;
	}
	public void setPw(String pw)
	{
		this.pw = pw;
	}
	public String getUser_name()
	{
		return user_name;
	}
	public void setUser_name(String user_name)
	{
		this.user_name = user_name;
	}
	public String getBirth_date()
	{
		return birth_date;
	}
	public void setBirth_date(String birth_date)
	{
		this.birth_date = birth_date;
	}
	public String getGender_id()
	{
		return gender_id;
	}
	public void setGender_id(String gender_id)
	{
		this.gender_id = gender_id;
	}
	public String getGender()
	{
		return gender;
	}
	public void setGender(String gender)
	{
		this.gender = gender;
	}
	public String getFind_id()
	{
		return find_id;
	}
	public void setFind_id(String find_id)
	{
		this.find_id = find_id;
	}
	public String getQuestion()
	{
		return question;
	}
	public void setQuestion(String question)
	{
		this.question = question;
	}
	public String getAnswer()
	{
		return answer;
	}
	public void setAnswer(String answer)
	{
		this.answer = answer;
	}
	public String getSignup_date()
	{
		return signup_date;
	}
	public void setSignup_date(String signup_date)
	{
		this.signup_date = signup_date;
	}
	
	
	
	
	
}

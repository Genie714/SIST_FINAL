package com.test.prj;

public class Sample
{

}

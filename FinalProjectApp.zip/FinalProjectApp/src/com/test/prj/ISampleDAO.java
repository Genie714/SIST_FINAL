/*==========================
	ISampleDAO.java
	- 인터페이스
 ==========================*/

package com.test.prj;

public interface ISampleDAO
{
	
}

package com.test.prj;

public class GroupMemberDTO
{
	private String group_id, match_id, name;

	public String getGroup_id()
	{
		return group_id;
	}

	public void setGroup_id(String group_id)
	{
		this.group_id = group_id;
	}

	public String getMatch_id()
	{
		return match_id;
	}

	public void setMatch_id(String match_id)
	{
		this.match_id = match_id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

}
